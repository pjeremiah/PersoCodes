public class ChildA extends Parent {
        String Name, Birthday;
        int Age;
  
      void information()
      {
        System.out.println("Name: " + Name);
        System.out.println("Age: " + Age);
        System.out.println("Birthday: " + Birthday);
      }
}