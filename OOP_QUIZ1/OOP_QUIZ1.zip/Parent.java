public class Parent {
        String Attitude, Hair_Color, Blood_type, Property;
        
        void checkParent()
        {
          System.out.println("The Attitude is: " + Attitude);
          System.out.println("The Hair Color is: " + Hair_Color);
          System.out.println("The Blood Type is: " + Blood_type);
          System.out.println("The Property is: " + Property);
        }

}