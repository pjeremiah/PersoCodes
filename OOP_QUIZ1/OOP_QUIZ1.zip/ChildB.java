public class ChildB extends ChildA {
  
  
}